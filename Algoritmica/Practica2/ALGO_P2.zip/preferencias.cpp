/*
	@author: Grupo ALGO
	@file: Mide tiempos de Comparación de Preferencias por método sencillo y Divide y Vencerás
*/

#include <iostream>
#include <cstdlib>
#include <climits>
#include <cassert>
#include <chrono>
#include <fstream> // Para usar ficheros
using namespace std;

//Realiza la Comparación de Preferencias por Divide y Vencerás
int preferencias(int *v, int i, int f);
//Realiza la mezcla del Mergesort
void merge(int *v, int i, int m, int f);
//Cuentas las inversiones que surgen de mezclar las dos mitades
int inversiones_merge(int *v, int i, int m, int f);
//Realiza la Comparación de Preferencias por el m�todo sencillo
int preferenciasFB(int *v, int n);
//Genera un número uniformemente distribuido en el intervalo [0,1) a partir de uno de los generadores disponibles en C.
double uniforme();


int main(int argc, char * argv[]){
	ofstream fsalida;

	if (argc <= 3){
  	cerr<<"\nError: El programa se debe ejecutar de la siguiente forma.\n\n";
  	cerr<<argv[0]<<" NombreFicheroSalida Semilla tamCaso1 tamCaso2 ... tamCasoN\n\n";

    return -1;
  }

	srandom(atoi(argv[2]));

	fsalida.open(argv[1]);
	if (!fsalida.is_open()) {
		cerr<<"Error: No se pudo abrir fichero para escritura "<<argv[1]<<"\n\n";
		return 0;
	}

	for(int argumento=3; argumento<argc; argumento++){
		int n = atoi(argv[argumento]);

		int * T = new int[n];
		assert(T);

    for (int j=0; j<n; j++) T[j]=j;
    //algoritmo de random shuffling the Knuth (permutación aleatoria)
    for (int j=n-1; j>0; j--) {
       double u=uniforme();
       int k=(int)(j*u);
       int tmp=T[j];
       T[j]=T[k];
       T[k]=tmp;
    }

  	cerr << "Ejecutando Mergesort para tam. caso: " << n << endl;

    chrono::high_resolution_clock::time_point t_antes = chrono::high_resolution_clock::now();
    cout << "Inversiones FB: " << preferenciasFB(T, n) << endl;
    chrono::high_resolution_clock::time_point t_despues = chrono::high_resolution_clock::now();
    unsigned long t_ejecucion = chrono::duration_cast<std::chrono::microseconds>(t_despues - t_antes).count();
    fsalida<<"FB: " << n<<" "<<t_ejecucion<<"\n";

  	t_antes = chrono::high_resolution_clock::now();
  	int resultado  = preferencias(T, 0, n-1);
  	t_despues = chrono::high_resolution_clock::now();
    cout << "Inversiones DyV: " << resultado << endl;
  	t_ejecucion = chrono::duration_cast<std::chrono::microseconds>(t_despues - t_antes).count();
  	//cerr << "\tTiempo de ejec. (us): " << t_ejecucion << " para tam. caso "<< n<<endl;
  	fsalida<<"DyV: " << n<<" "<<t_ejecucion<<"\n";
  	delete [] T;
	}

	fsalida.close();

	return 0;
}

double uniforme() {
  int t = rand();
  double f = ((double)RAND_MAX+1.0);
  return (double)t/f;
}


void merge(int *v, int i, int m, int f) {
   int *aux = new int[m-i+1];
   for(int j=i; j<=m; j++)
       aux[j-i] = v[j];

   int c1=0, c2=m+1;
   for(int j=i; j<=f; j++) {
       if(aux[c1] < v[c2]) {
           v[j] = aux[c1++];
           if(c1==m-i+1)
               for(int k=c2; k<=f; k++)
                   v[++j] = v[k];
       }
       else {
           v[j] = v[c2++];
           if(c2==f+1)
               for(int k=c1; k<=m-i; k++)
                   v[++j] = aux[k];
       }
   }
   delete [] aux;
}


int preferencias(int *v, int i, int f) {
  int inversiones = 0;

  if(i!=f) {
       int m = (i+f)/2;
       inversiones += preferencias(v, i, m);
       inversiones += preferencias(v, m+1, f);
       inversiones += inversiones_merge(v, i, m, f);
       merge(v, i, m, f);
   }
   return inversiones;
}

int inversiones_merge(int *v, int i, int m, int f){
  int j = i;
  int k = m+1;
  int inversiones = 0;

  while(j<=m && k<=f){
    if(v[j]>v[k]){
      inversiones += m-j+1;
      k++;
    }
    else
      j++;
  }
  return inversiones;
}

int preferenciasFB(int *v, int n){
  int inversiones = 0;
  for(int i=0; i<n; i++){
      for(int j=i+1; j<n; j++){
        if(v[i]>v[j])
          inversiones++;
      }
  }
  return inversiones;
}
