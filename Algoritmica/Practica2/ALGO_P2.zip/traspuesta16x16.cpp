/*
	@author: Grupo ALGO
	@file: Traspone matriz cuadrada con 2^8 elementos.
*/

#include <iostream>
#include <cmath>
using namespace std;


void trasponer(int **m, int n);
void trasponerDyV(int **m, int fila_inicio, int fila_fin, int columna_inicio, int columna_fin);
void intercambiar (int **m, int fila_iniA, int columna_iniA, int fila_iniB, int columna_iniB, int dimension);
void mostrarMatriz(int **m, int n);
void rellenarMatriz(int **m, int n);
inline void vaciarMatriz(int **matriz, int nFilas);

int main(){
	int **matriz;

	matriz = new int*[16];
	for(int i=0; i<16; i++){
		matriz[i] = new int[16];
	}
	rellenarMatriz(matriz, 16);
	mostrarMatriz(matriz, 16);

	trasponer(matriz, 16);

	cout << "Matriz traspuesta: " << endl;
	mostrarMatriz(matriz, 16);

	vaciarMatriz(matriz, 16);

	return 0;
}

void trasponer(int **m, int n){
	trasponerDyV(m, 0, n-1, 0, n-1);
}

void trasponerDyV(int **m, int fila_inicio, int fila_fin, int columna_inicio, int columna_fin){
	if (fila_inicio < fila_fin){
		int fila_medio = (fila_inicio+fila_fin)/2;
		int columna_medio = (columna_inicio+columna_fin)/2;
		trasponerDyV(m, fila_inicio, fila_medio, columna_inicio, columna_medio);
		trasponerDyV(m, fila_inicio, fila_medio, columna_medio+1, columna_fin);
		trasponerDyV(m, fila_medio+1, fila_fin,  columna_inicio, columna_medio);
		trasponerDyV(m, fila_medio+1, fila_fin,  columna_medio+1, columna_fin);
		intercambiar(m, fila_medio+1, columna_inicio, fila_inicio, columna_medio+1, fila_fin-fila_medio);
    mostrarMatriz(m, 16);
	}
}

void intercambiar (int **m, int fila_iniA, int columna_iniA, int fila_iniB, int columna_iniB, int dimension){
	for (int i=0; i<=dimension-1; i++){
		for (int j=0; j<=dimension-1; j++){
			int aux = m[fila_iniA+i][columna_iniA+j];
			m[fila_iniA+i][columna_iniA+j] = m[fila_iniB+i][columna_iniB+j];
			m[fila_iniB+i][columna_iniB+j]=aux;
		}

	}
}

void mostrarMatriz(int **m, int n){
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++){
      cout << m[i][j] << " ";
      if(m[i][j]<10) cout << "  ";
			if(m[i][j]<100) cout << " ";
    }
    cout << endl;
  }
  cout << endl;
}

void rellenarMatriz(int **m, int n){
  int contador = 1;
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++){
      m[i][j] = contador;
      ++contador;
    }
  }
}

inline void vaciarMatriz(int **matriz, int nFilas){
	for(int i=0; i<nFilas; i++){
		delete [] matriz[i];
	}
	delete [] matriz;
}
