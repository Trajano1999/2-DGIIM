/*
	@author: Grupo ALGO
	@file: Traspone matriz de tamaño nxm
*/

#include <iostream>
#include <cmath>

using namespace std;

//Traspone matriz de tamaño 2^k por Divide y Vencerás
void trasponer(int **m, int n);

//Traspone matriz de tamaño 2^k por Divide y Vencerás (Realiza las llamadas recursivas)
void trasponerDyV(int **m, int fila_inicio, int fila_fin, int columna_inicio, int columna_fin);

//Intercambia la submatriz superior derecha con la inferior izquierda
void intercambiar (int **m, int fila_iniA, int columna_iniA, int fila_iniB, int columna_iniB, int dimension);

//Traspone matriz de tamaño nxm
void trasponer(int ** &matriz, int n, int m);

//Libera la memoria reservada para la matriz
inline void vaciarMatriz(int **matriz, int nFilas);


int main(){
	int **matriz;
	int n, m;

	cout << "Introduce valores: " << endl;
	cout << "\t n: ";
	cin >> n;
	cout << "\t m: ";
	cin >> m;

	matriz = new int*[n];
	for(int i=0; i<n; i++){
		matriz[i] = new int[m];
	}

  int contador = 1;
	for(int i=0; i<n; i++){
		for(int j=0; j<m; j++){
			matriz[i][j] = contador;
			cout << contador << " ";
      contador++;
		}
		cout << endl;
	}

	trasponer(matriz, n, m);

	cout << "Matriz traspuesta: " << endl;
	for(int i=0; i<m; i++){
		for(int j=0; j<n; j++){
			cout << matriz[i][j] << " ";
		}
		cout << endl;
	}

	vaciarMatriz(matriz, m);

	return 0;
}

void trasponer(int **m, int n){
  trasponerDyV(m, 0, n-1, 0, n-1);
}




void trasponerDyV(int **m, int fila_inicio, int fila_fin, int columna_inicio, int columna_fin){
  if (fila_inicio < fila_fin){
    int fila_medio = (fila_inicio+fila_fin)/2;
    int columna_medio = (columna_inicio+columna_fin)/2;
    trasponerDyV(m, fila_inicio, fila_medio, columna_inicio, columna_medio);
    trasponerDyV(m, fila_inicio, fila_medio, columna_medio+1, columna_fin);
    trasponerDyV(m, fila_medio+1, fila_fin,  columna_inicio, columna_medio);
    trasponerDyV(m, fila_medio+1, fila_fin,  columna_medio+1, columna_fin);
    intercambiar(m, fila_medio+1, columna_inicio, fila_inicio, columna_medio+1, fila_fin-fila_medio);
  }
}

void intercambiar (int **m, int fila_iniA, int columna_iniA, int fila_iniB, int columna_iniB, int dimension){
  for (int i=0; i<=dimension-1; i++){
    for (int j=0; j<=dimension-1; j++){
      int aux = m[fila_iniA+i][columna_iniA+j];
      m[fila_iniA+i][columna_iniA+j] = m[fila_iniB+i][columna_iniB+j];
      m[fila_iniB+i][columna_iniB+j]=aux;
    }

  }
}

void trasponer(int ** &matriz, int n, int m){
  int dimension = pow(2, ceil(log2(max(n, m))));
  int **aux;
  aux = new int*[dimension];
  for(int i=0; i<dimension; i++)
  aux[i] = new int[dimension];

  for(int i=0; i<n; i++){
    for(int j=0; j<m; j++){
      aux[i][j] = matriz[i][j];
    }
  }

  trasponer(aux, dimension);

  vaciarMatriz(matriz, n);

  matriz = new int*[m];
  for(int i=0; i<m; i++){
    matriz[i] = new int[n];
  }

  for(int i=0; i<m; i++){
    for(int j=0; j<n; j++){
      matriz[i][j] = aux[i][j];
    }
  }

  vaciarMatriz(aux, dimension);

}

inline void vaciarMatriz(int **matriz, int nFilas){
  for(int i=0; i<nFilas; i++){
    delete [] matriz[i];
  }
  delete [] matriz;
}
